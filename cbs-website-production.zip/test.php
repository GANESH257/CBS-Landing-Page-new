<?php
phpinfo();
?> 
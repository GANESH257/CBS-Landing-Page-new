"use strict";(()=>{var e={};e.id=402,e.ids=[402],e.modules={1287:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},8765:(e,r,s)=>{s.r(r),s.d(r,{config:()=>d,default:()=>l,routeModule:()=>p});var t={};s.r(t),s.d(t,{default:()=>handler});var o=s(1802),a=s(7153),n=s(6249);let i=require("nodemailer");var u=s.n(i);async function handler(e,r){if("POST"!==e.method)return r.status(405).json({error:"Method not allowed"});try{let{name:s,phone:t,email:o,message:a}=e.body;if(!s||!t||!o)return r.status(400).json({error:"Missing required fields"});if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(o))return r.status(400).json({error:"Invalid email format"});let n=u().createTransport({host:process.env.SMTP_HOST,port:process.env.SMTP_PORT,secure:!0,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}}),i={from:process.env.SMTP_USER,to:process.env.ADMIN_EMAIL,subject:`New Consultation Request from ${s}`,text:`
New consultation request received:

Name: ${s}
Phone: ${t}
Email: ${o}
Message: ${a||"No message provided"}
      `,html:`
<h2>New consultation request received:</h2>
<p><strong>Name:</strong> ${s}</p>
<p><strong>Phone:</strong> ${t}</p>
<p><strong>Email:</strong> ${o}</p>
<p><strong>Message:</strong> ${a||"No message provided"}</p>
      `};return await n.sendMail(i),r.status(200).json({success:!0,message:"Thank you for your request! We will contact you shortly."})}catch(e){return console.error("Email sending error:",e),r.status(500).json({error:"Failed to send email. Please try again later."})}}let l=(0,n.l)(t,"default"),d=(0,n.l)(t,"config"),p=new o.PagesAPIRouteModule({definition:{kind:a.x.PAGES_API,page:"/api/send_email",pathname:"/api/send_email",bundlePath:"",filename:""},userland:t})}};var r=require("../../webpack-api-runtime.js");r.C(e);var __webpack_exec__=e=>r(r.s=e),s=r.X(0,[222],()=>__webpack_exec__(8765));module.exports=s})();